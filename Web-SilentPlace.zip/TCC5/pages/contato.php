<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Contato</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/contato.css">
    <link rel="stylesheet" href="../assets/css/animacoes.css">
</head>

<body>
    <header>
        <?php require_once '../includes/header.php'; ?>
    </header>
    <main class="anTransforma">
        <div class="first-part">
            <h1>Contato</h1>
            <h2>Entre em contato conosco para mais informações</h2>
        </div>

        <div class="info-section">
            <p>Home / Contato</p>
        </div>

        <div class="second-part" style="margin-bottom: -40px;">
            <div class="row">
                <div class="col">
                    <div class="icon"><i class="fas fa-map-marker-alt"></i></div>
                    <h2>Endereço</h2>
                    <p>Rua Vergueiro, 245, Bairro Central, São Paulo, SP</p>
                </div>
                <div class="col">
                    <div class="icon"><i class="fas fa-phone-alt"></i></div>
                    <h2>Informações de Contato</h2>
                    <p>E-mail: contact.silentplace@gmail.com<br>Telefone: +55 11 1234-5678</p>
                </div>
                <div class="col">
                    <div class="icon"><i class="fas fa-clock"></i></div>
                    <h2>Horário de Atendimento</h2>
                    <p>Segunda a Sexta-feira: 9:00 - 18:00</p>
                </div>
            </div>
        </div>

        <div class="third-part">
            <h1>Envie sua Mensagem</h1>
            <p>Preencha o formulário abaixo e entraremos em contato em breve.</p>
        </div>

        <div class="fourth-part">
            <div class="form-container">
                <form id="contactForm">
                    <input type="text" id="name" placeholder="Seu nome" required>
                    <input type="email" id="email" placeholder="Seu e-mail" required>
                    <textarea id="message" required rows="5" placeholder="Sua mensagem"></textarea>
                    <button type="submit" id="submitButton" disabled>Enviar Mensagem</button>
                </form>
            </div>
            <div class="map-container">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3658.03227505835!2d-46.6445007!3d-23.548915!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce597ea0b8b3bb%3A0x503f7f68c6fd5d89!2sPra%C3%A7a%20da%20Rep%C3%BAblica!5e0!3m2!1spt-BR!2sbr!4v1602203723594!5m2!1spt-BR!2sbr"></iframe>
            </div>
        </div>
    </main>
    <footer>
        <?php require_once '../includes/footer.php'; ?>
    </footer>
    <script>
        // Função para habilitar o botão de envio quando todos os campos estiverem preenchidos
        const form = document.getElementById('contactForm');
        const submitButton = document.getElementById('submitButton');

        form.addEventListener('input', function() {
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const message = document.getElementById('message').value;

            // Habilita o botão se todos os campos estiverem preenchidos
            if (name && email && message) {
                submitButton.disabled = false;
            } else {
                submitButton.disabled = true;
            }
        });

        // Envio do formulário e exibição do alert
        form.addEventListener('submit', function(event) {
            event.preventDefault(); // Impede o envio real para testar
            alert('Mensagem enviada com sucesso!');
        });
    </script>
</body>

</html>
