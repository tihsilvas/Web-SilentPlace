<?php
session_start();

// Verifica se o usuário está logado localmente, com base na variável $_SESSION['logado']
$loginStatus = isset($_SESSION['logado']) && $_SESSION['logado'] === true;

// Verifica se o usuário está logado via Firebase
$firebaseLogin = isset($_SESSION['userName']) && isset($_SESSION['userPhoto']);

// A variável $usuarioLogado será verdadeira se qualquer uma das condições for verdadeira
$usuarioLogado = $loginStatus || $firebaseLogin;

// Se o usuário não estiver logado, redireciona para a página de login
if (!$usuarioLogado) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catálogo de Abafadores de Som</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/catalogo.css">
    <link rel="stylesheet" href="../assets/css/animacoes.css">
</head>

<body class="catalogo">
    <header>
        <?php require_once '../includes/header.php'; ?>
    </header>
    <main>
        <!-- Container Principal -->
        <div class="container1 anTransforma">
            <div class="content">
                <h1>Catálogo de Abafadores de Som</h1>
                <p>Escolha o abafador que melhor se adapta às suas necessidades e preferências.</p>
            </div>
        </div>

        <!-- Container de Produtos -->
        <div class="container2">
            <h1>Escolha o seu Abafador</h1>
            <div class="services">
                <!-- Produto 1 -->
                <div class="service-item">
                    <img src="../assets/img/index/abafador1.png" alt="Abafador Rosa">
                    <h1>Abafador Rosa</h1>
                    <p>Ideal para quem procura conforto e eficiência com um toque de estilo.</p>
                    <button class="btn-outline-red" data-product="Abafador Rosa">Selecionar</button>
                </div>
                <!-- Produto 2 -->
                <div class="service-item">
                    <img src="../assets/img/index/abafador2.png" alt="Abafador Premium">
                    <h1>Abafador Preto</h1>
                    <p>Para quem busca o máximo de conforto e performance com um design moderno.</p>
                    <button class="btn-outline-red" data-product="Abafador Preto">Selecionar</button>
                </div>
                <!-- Produto 3 -->
                <div class="service-item">
                    <img src="../assets/img/index/abafador3.png" alt="Abafador Profissional">
                    <h1>Abafador Azul</h1>
                    <p>Com alto desempenho e ajuste perfeito, ideal para ambientes de trabalho intensos.</p>
                    <button class="btn-outline-red" data-product="Abafador Azul">Selecionar</button>
                </div>
            </div>
        </div>

        <!-- Container de Tamanho -->
        <div class="container3">
            <h1>Escolha o Tamanho do Abafador</h1>
            <div class="size-selection">
                <!-- Tamanho Pequeno -->
                <div class="icon-box" data-size="Pequeno">
                    <i class="fas fa-ruler-combined"></i>
                    <p class="tm">Tamanho Pequeno</p>
                    <p>Largura: 15 cm a 17 cm</p>
                    <p>Altura: 16 cm a 18 cm</p>
                </div>
                <!-- Tamanho Médio -->
                <div class="icon-box" data-size="Médio">
                    <i class="fas fa-ruler-combined"></i>
                    <p class="tm">Tamanho Médio</p>
                    <p>Largura: 17 cm a 19 cm</p>
                    <p>Altura: 18 cm a 20 cm</p>
                </div>
                <!-- Tamanho Grande -->
                <div class="icon-box" data-size="Grande">
                    <i class="fas fa-ruler-combined"></i>
                    <p class="tm">Tamanho Grande</p>
                    <p>Largura: 19 cm a 21 cm</p>
                    <p>Altura: 20 cm a 22 cm</p>
                </div>
            </div>
        </div>

        <!-- Container de Resumo -->
        <div class="container4">
            <div class="background-overlay">
                <h1>Resumo da Compra</h1>
                <p id="selected-product"></p>
                <p id="selected-size"></p>
                <button id="btn-buy" class="btn-buy">Comprar Agora</button>
            </div>
        </div>

        <!-- Modal de Confirmação -->
        <div id="confirmationModal" class="modal" style="margin-top: -10vh;">
            <div class="modal-content">
                <div class="modal-header" style="margin-bottom: -6vh;">
                    <center>
                        <div class="img-logo" style="width: 20vh; height: 20vh; margin-bottom: -6vh;">
                            <img style="width: 100%; height: 100%;" src="../assets/img/logo-background.png" alt="Logo da Empresa">
                        </div>
                    </center>
                    <h2>Confirmar Compra</h2>
                </div>
                <div class="modal-body">
                    <p style="color: gray; margin-top: 6vh;">Tem certeza que deseja comprar?</p>
                </div>
                <div class="modal-footer">
                    <button class="modal-button" id="confirmPurchase">Confirmar</button>
                    <button class="modal-button" id="cancelPurchase">Cancelar</button>
                </div>
            </div>
        </div>

        <!-- Modal de Seleção de Forma de Pagamento -->
        <div id="paymentModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Forma de Pagamento</h2>
                </div>
                <div class="modal-body">
                    <button class="modal-button" id="payWithCard">Cartão</button>
                    <button class="modal-button" id="payWithPix">Pix</button>
                </div>
            </div>
        </div>

        <!-- Modal para Pagamento com Cartão -->
        <div id="cardPaymentModal" class="modal" style="margin-top: -5vh;">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Pagamento com Cartão</h2>
                </div>
                <div class="modal-body">
                    <form id="cardForm">
                        <label for="cardNumber">Número do Cartão:</label>
                        <input type="text" id="cardNumber" placeholder="0000 0000 0000 0000" required>

                        <label for="cardExpiry">Data de Validade:</label>
                        <input type="text" id="cardExpiry" placeholder="MM/AA" required>

                        <label for="cardCVC">Código de Segurança:</label>
                        <input type="text" id="cardCVC" placeholder="CVC" required>

                        <button type="submit" class="modal-button">Confirmar</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Modal para Pagamento com Pix -->
        <div id="pixPaymentModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Pagamento com Pix</h2>
                </div>
                <div class="modal-body">
                    <div id="qrCode">
                        <!-- QR Code Gerado Dinamicamente -->
                        <img src="https://api.qrserver.com/v1/create-qr-code/?data=MB%20PRA%20NOIZ&size=200x200" alt="QR Code Fixo">

                    </div>
                </div>
            </div>
        </div>

        <!-- Modal para Exibir Código -->
        <div id="codeModal" class="modal">
            <div class="modal-content confirmation-code-modal">
                <div class="modal-body">
                    <p>Compra Confirmada! Seu código é: <span id="confirmation-code"></span></p>
                    <p>
                        <a href="../scripts/script-maquinas/email-codigo.php" id="sendCodeEmailLink" class="modal-link" style="color: #0cbce4; font-size:15px;text-decoration: none;">Enviar código por e-mail</a>
                    </p>
                </div>
                <div class="modal-footer">
                    <button class="modal-button" id="closeCodeModal">Fechar</button>
                </div>
            </div>
        </div>
    </main>
    <script>
        let selectedProduct = null;
        let selectedSize = null;
        const productButtons = document.querySelectorAll('.btn-outline-red');
        const sizeIcons = document.querySelectorAll('.icon-box[data-size]');
        const buyButton = document.getElementById('btn-buy');
        const selectedProductElement = document.getElementById('selected-product');
        const selectedSizeElement = document.getElementById('selected-size');
        const confirmationModal = document.getElementById('confirmationModal');
        const confirmPurchaseButton = document.getElementById('confirmPurchase');
        const cancelPurchaseButton = document.getElementById('cancelPurchase');
        const codeModal = document.getElementById('codeModal');
        const confirmationCodeElement = document.getElementById('confirmation-code');
        const closeCodeModalButton = document.getElementById('closeCodeModal');

        // Preços dos tamanhos
        const tamanhoPrecos = {
            Pequeno: 10,
            Médio: 12,
            Grande: 14
        };

        // Função para desmarcar todos os tamanhos
        function deselectAllSizes() {
            sizeIcons.forEach(icon => {
                icon.classList.remove('selected');
            });
        }

        // A função para verificar se a compra está pronta
        function checkIfReadyToBuy() {
            if (selectedProduct && selectedSize) {
                buyButton.classList.add('active');
                buyButton.style.pointerEvents = 'auto';
            } else {
                buyButton.classList.remove('active');
                buyButton.style.pointerEvents = 'none';
            }
        }

        // Substituindo a função de código aleatório por um código fixo
        function generateFixedCode() {
            return '6978'; // Código fixo que será sempre gerado
        }

        // Adiciona a seleção do produto
        productButtons.forEach(button => {
            button.addEventListener('click', () => {
                productButtons.forEach(btn => btn.classList.remove('selected'));
                button.classList.add('selected');
                selectedProduct = button.getAttribute('data-product');
                selectedProductElement.textContent = `Produto Selecionado: ${selectedProduct}`;
                checkIfReadyToBuy();
            });
        });

        // Adiciona a seleção do tamanho
        sizeIcons.forEach(icon => {
            icon.addEventListener('click', () => {
                deselectAllSizes();
                icon.classList.add('selected');
                selectedSize = icon.getAttribute('data-size');

                // Adiciona o preço ao resumo
                const preco = tamanhoPrecos[selectedSize] || 0;
                selectedSizeElement.textContent = `Tamanho Selecionado: ${selectedSize} - Preço: R$ ${preco.toFixed(2)}`;

                checkIfReadyToBuy();
            });
        });

        // Mostrar modal de confirmação ao clicar no botão "Comprar Agora"
        buyButton.addEventListener('click', () => {
            if (selectedProduct && selectedSize) {
                const preco = tamanhoPrecos[selectedSize] || 0;
                confirmationModal.style.display = 'block';

                // Adicionar preço ao resumo de compra no modal
                const modalBody = confirmationModal.querySelector('.modal-body');
                modalBody.innerHTML = `
            <p style="color: gray; margin-top: 10vh;">Tamanho Selecionado: ${selectedSize} Preço: R$ ${preco.toFixed(2)}</p>
            <p style="color: gray; margin-top: 0vh;">Tem certeza que deseja comprar?</p>
        `;
            }
        });

        // Lidar com o botão de confirmação
        confirmPurchaseButton.addEventListener('click', () => {
            confirmationModal.style.display = 'none';
            openPaymentModal();
        });

        // Lidar com o botão de cancelamento
        cancelPurchaseButton.addEventListener('click', () => {
            confirmationModal.style.display = 'none';
        });

        // Fechar modal de código de confirmação
        closeCodeModalButton.addEventListener('click', () => {
            codeModal.style.display = 'none';
        });

        // Elementos dos modais
        const paymentModal = document.getElementById('paymentModal');
        const cardPaymentModal = document.getElementById('cardPaymentModal');
        const pixPaymentModal = document.getElementById('pixPaymentModal');

        // Botões para selecionar a forma de pagamento
        const payWithCardButton = document.getElementById('payWithCard');
        const payWithPixButton = document.getElementById('payWithPix');

        // Formulário de cartão
        const cardForm = document.getElementById('cardForm');

        // Função para abrir o modal de seleção de pagamento
        function openPaymentModal() {
            paymentModal.style.display = 'block';
        }

        // Fechar modais genéricos
        function closeModal(modal) {
            modal.style.display = 'none';
        }

        // Função para abrir o modal de pagamento
function openPaymentModal() {
    paymentModal.style.display = 'block';
}

// Evento para selecionar pagamento com cartão
payWithCardButton.addEventListener('click', () => {
    closeModal(paymentModal); // Fecha o modal de seleção de pagamento
    cardPaymentModal.style.display = 'block'; // Abre o modal de pagamento com cartão
});

// Função para fechar modais
function closeModal(modal) {
    modal.style.display = 'none';
}

// Evento para confirmar pagamento com cartão
cardForm.addEventListener('submit', (event) => {
    event.preventDefault();
    closeModal(cardPaymentModal); // Fecha o modal de pagamento com cartão
    openConfirmationCodeModal();  // Abre o modal com o código de confirmação
});



        // Evento para selecionar pagamento com Pix
        payWithPixButton.addEventListener('click', () => {
            closeModal(paymentModal);
            pixPaymentModal.style.display = 'block';

            // Inicia a contagem regressiva
            let timeLeft = 15; // 20 segundos de exibição do QR Code

            // Substitui o link do QR Code Pix com o link gerado
            const qrCodePix = document.querySelector('#qrCode img');
            qrCodePix.src = "https://api.qrserver.com/v1/create-qr-code/?data=MB%20PRA%20NOIZ&size=200x200"; // Aqui você pode substituir pela URL do QR Code real

            // Inicia a contagem regressiva
            countdown = setInterval(() => {
                timeLeft -= 1;

                if (timeLeft <= 0) {
                    clearInterval(countdown); // Limpa a contagem
                    closeModal(pixPaymentModal); // Fecha o modal do Pix
                    openConfirmationCodeModal(); // Abre o modal com o código de confirmação
                }
            }, 1000); // Atualiza a cada 1 segundo
        });

        // Evento para confirmar pagamento com cartão
        cardForm.addEventListener('submit', (event) => {
            event.preventDefault();
            closeModal(cardPaymentModal);
            openConfirmationCodeModal();
        });

        // Função para abrir o modal de código de confirmação
        function openConfirmationCodeModal() {
            codeModal.style.display = 'block';
            confirmationCodeElement.textContent = generateFixedCode();
        }

        // Abrir o modal de pagamento ao confirmar compra
        confirmPurchaseButton.addEventListener('click', () => {
            confirmationModal.style.display = 'none';
            openPaymentModal();
        });
    </script>
    <style>
        .modal-button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            margin: 10px;
            cursor: pointer;
            border-radius: 5px;
        }

        .modal-button:hover {
            background-color: #0056b3;
        }

        .modal-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }

      

#cardForm label {
    font-size: 14px;
    font-weight: bold;
    margin-bottom: 5px;
    color: #333;
}

#cardForm input {
    width: 100%;
    padding-top: 7px;
    padding-bottom: 7px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
    color: #333;
    background-color: #f9f9f9;
    transition: border-color 0.3s;
}

#cardForm input:focus {
    border-color: #007bff;
    background-color: #fff;
    outline: none;
}

#cardForm button {
    width: 100%;
   margin-left: 1px;
    background-color: #007bff;
    color: #fff;
    font-size: 16px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
}

#cardForm button:hover {
    background-color: #0056b3;
}

        
    </style>
</body>

</html>