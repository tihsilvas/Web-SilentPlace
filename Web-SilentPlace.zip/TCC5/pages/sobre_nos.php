<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Exemplo</title>
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/sobre_nos.css">
    <link rel="stylesheet" href="../assets/css/animacoes.css">
</head>

<body>
    <header>
        <?php require_once '../includes/header.php'; ?>
    </header>
    <main class="sobre-nos">
        <div class="content1 anTransforma">
            <div class="border-box">
                SOBRE NÓS
            </div>
        </div>
        <div class="line fade-in"></div>

        <div class="content2 fade-in">
            <img class="abafador-image" src="../assets/img/sobre_nos/Foto selecionada.jpg" alt="Imagem">
            <div class="text">
                Na calçada movimentada, passos rápidos ecoam. O sol brilha alto, refletindo no asfalto quente. Risos se
                misturam aos sons da cidade, enquanto pessoas de todas as idades se apressam em suas rotinas. Nas
                esquinas,
                vendedores ambulantes oferecem seus produtos com entusiasmo, criando uma atmosfera vibrante e colorida.
                No
                meio do tumulto urbano, histórias pessoais se desenrolam silenciosamente, cada uma contendo seus
                próprios
                dramas e alegrias, esperando para serem descobertas pelos olhos curiosos dos transeuntes.
            </div>
        </div>
        <div class="separator fade-in"></div>
        <div class="content3 fade-in">
            <div class="box">
                <div class="large-text">
                    DESEN<br>VOLVE<br>DORES.
                </div>
            </div>
            <div class="images-container">
                <div class="fade-in">
                    <img src="../assets/img/lais.jpg" alt="Imagem 1" style="width: 100%; height: 100%;">
                </div>
                <div class="fade-in" style="opacity: 0">
                    <img src="image2.jpg" alt="Imagem 2">
                </div>
                <div class="fade-in">
                    <img src="../assets/img/laue.jpg" alt="Imagem 3" style="width: 100%; height: 100%;">
                </div>
                <div class="fade-in" style="opacity: 0">
                    <img src="image4.jpg" alt="Imagem 4">
                    <div class="white-square"></div>
                </div>
                <div class="fade-in">
                    <img src="../assets/img/lorenzo.jpg" alt="Imagem 5" style="width: 100%; height: 100%;">
                </div>
                <div class="fade-in">
                    <img src="../assets/img/larissa.jpg" alt="Imagem 6" style="width: 100%; height: 100%;">
                </div>
                <div class="fade-in">
                    <img src="../assets/img/thigas.jpg" alt="Imagem 7" style="width: 100%; height: 100%;">
                </div>
                <div class="fade-in">
                    <img src="../assets/img/jooj.jpg" alt="Imagem 8" style="width: 100%; height: 100%;">
                </div>
                <div class="fade-in" style="opacity: 0">
                    <img src="image9.jpg" alt="Imagem 9">
                    <div class="white-square"></div>
                </div>
            </div>
        </div>
    </main>
    <footer>
        <?php require_once '../includes/footer.php'; ?>
    </footer>

    <script src="../assets/js/animacao.js"></script>

</body>

</html>