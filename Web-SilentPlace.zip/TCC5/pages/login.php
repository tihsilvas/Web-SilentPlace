<?php
session_start();

if (isset($_SESSION['erro_login'])) {
    echo "<script>alert('{$_SESSION['erro_login']}');</script>";
    unset($_SESSION['erro_login']);
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Login</title>
    <link rel="stylesheet" href="../assets/css/estilo-gerais.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/animacoes.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/voltar-icone.css">
    <link rel="stylesheet" href="../assets/css/formulario.css">
</head>

<body>
    <!-- Versão Mobile -->
    <a href="../index.php" class="back-icon"><i class="fas fa-arrow-left"></i></a>
    <div class="mobile-container anTransforma">
        <div class="mobile-form-container" id="mobile-form-container">
            <div class="mobile-form-wrapper mobile-login-form" id="login-form">
                <h1>Login</h1>
                <form id="mobile-login-form">
                       <!-- Botão Google na versão Mobile -->
                    <div class="google-button" id="googleLoginMobile">
                        <img src="https://developers.google.com/identity/images/g-logo.png" alt="Google logo">
                        Continuar com Google
                    </div>
                    <input type="email" name="txt_email" placeholder="E-mail" required />
                    <input type="password" name="txt_senha" placeholder="Senha" required />
                    <button type="submit">Entrar</button>
                    <a href="#">Recuperar Senha</a>
                    <a class="mobile-toggle-link" onclick="toggleMobileForm()">Não tem uma conta? Cadastre-se</a>
                </form>
            </div>
            <div class="mobile-form-wrapper mobile-register-form" id="register-form">
                <h1>Cadastro</h1>
                <form id="mobile-register-form">
                    <input type="text" name="txt_nome" placeholder="Nome" required />
                    <input type="email" name="txt_email" placeholder="E-mail" required />
                    <input type="password" name="txt_senha" placeholder="Senha" required />
                    <input type="password" name="confirm-password" placeholder="Confirmar Senha" required />
                    <button type="submit">Registrar</button>
                    <a class="mobile-toggle-link" onclick="toggleMobileForm()">Já tem uma conta? Entre</a>
                </form>
            </div>
        </div>
    </div>

    <!-- Versão Web -->
    <div class="container anTransforma">
        <!-- Formulário de Login -->
        <div class="form-container sign-in-container">
            <form action="../scripts/script-form/validar.php" method="POST">
                <h1>Login</h1>
                <!-- Botão Google na versão Web --> 
                <div class="google-button" id="googleLoginWeb">
                    <img src="https://developers.google.com/identity/images/g-logo.png" alt="Google logo">
                    Continuar com Google
                </div>

                <div class="form-group">
                    <input type="email" name="txt_email" id="email" placeholder="E-mail" required />
                    <div class="error-balloon" id="emailError">
                        <img src="https://cdn-icons-png.flaticon.com/512/1828/1828944.png" alt="Alert Icon"> E-mail inválido.
                    </div>
                </div>
                <div class="form-group">
                    <input type="password" name="txt_senha" id="password" placeholder="Senha" required />
                    <div class="error-balloon" id="passwordError">
                        <img src="https://cdn-icons-png.flaticon.com/512/1828/1828944.png" alt="Alert Icon"> Senha inválida.
                    </div>
                </div>
             
                <button type="submit" id="loginButton" disabled>Entrar</button>
                <p><a href="../scripts/script-form/recuperacao_senha/inserir_email.html">Recuperar Senha</a></p>               
            </form>
        </div>

        <!-- Formulário de Cadastro -->
        <div class="form-container sign-up-container">
            <form action="../scripts/script-form/processar.php" method="POST">
                <h1>Cadastro</h1>
                <div class="form-group">
                    <input type="text" name="txt_nome" id="username" placeholder="Nome" required />
                    <div class="error-balloon" id="usernameError">
                        <img src="https://cdn-icons-png.flaticon.com/512/1828/1828944.png" alt="Alert Icon"> Nome inválido.
                    </div>
                </div>
                <div class="form-group">
                    <input type="email" name="txt_email" id="regEmail" placeholder="E-mail" required />
                    <div class="error-balloon" id="regEmailError">
                        <img src="https://cdn-icons-png.flaticon.com/512/1828/1828944.png" alt="Alert Icon"> E-mail inválido.
                    </div>
                </div>
                <div class="form-group">
                    <input type="password" name="txt_senha" id="regPassword" placeholder="Senha" required />
                    <div class="error-balloon" id="regPasswordError">
                        <img src="https://cdn-icons-png.flaticon.com/512/1828/1828944.png" alt="Alert Icon"> Senha inválida.
                    </div>
                </div>
                <div class="form-group confirm-password">
                    <input type="password" name="confirmPassword" id="confirmPassword" placeholder="Confirmar Senha" required />
                    <div class="error-balloon" id="confirmPasswordError">
                        <img src="https://cdn-icons-png.flaticon.com/512/1828/1828944.png" alt="Alert Icon"> As senhas não coincidem.
                    </div>
                </div>
                
                <center>
                <div class="form-group terms-group">
                    <label>
                        <input type="checkbox" name="accept_terms" id="acceptTerms" required />
                        <a href="../termos-politica.html" target="_blank">Eu aceito os termos de política de privacidade.</a>
                    </label>
                    <div class="error-balloon" id="acceptTermsError">
                        <img src="https://cdn-icons-png.flaticon.com/512/1828/1828944.png" alt="Alert Icon"> Você precisa aceitar os termos.
                    </div>
                </div>
                </center>

                <button type="submit" id="registerButton" disabled>Registrar</button>
            </form>
        </div>

        <!-- Apresentação -->
        <div class="overlay-container">
            <div class="overlay">
                <div class="overlay-panel overlay-left">
                    <h1>Bem-vindo de volta!</h1>
                    <button class="ghost" id="signInOverlay">Entrar</button>
                </div>
                <div class="overlay-panel overlay-right">
                    <h1>Bem-vindo</h1>
                    <button class="ghost" id="signUpOverlay">Cadastre-se</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-auth.js"></script>
    <script>
        // Configuração do Firebase
        const firebaseConfig = {
            apiKey: "AIzaSyAJ_jK7lXhkXCT9Xok9QssQ28jtkhaj_Yo",
            authDomain: "login-cf9ce.firebaseapp.com",
            databaseURL: "https://login-cf9ce-default-rtdb.firebaseio.com",
            projectId: "login-cf9ce",
            storageBucket: "login-cf9ce.appspot.com",
            messagingSenderId: "992197061986",
            appId: "1:992197061986:web:77d612637edff5d867903b"
        };

        // Inicializar Firebase
        firebase.initializeApp(firebaseConfig);

        const auth = firebase.auth();
        const provider = new firebase.auth.GoogleAuthProvider();

        function handleGoogleLogin() {
            auth.signInWithPopup(provider).then((result) => {
                const user = result.user;
                user.getIdToken().then(idToken => {
                    console.log('ID Token:', idToken); // Verifique se o token é gerado corretamente

                    fetch('../scripts/script-form/verify_token.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: `idToken=${encodeURIComponent(idToken)}`
                    }).then(response => {
                        // Verifique se a resposta é JSON
                        return response.text().then(text => {
                            try {
                                return JSON.parse(text);
                            } catch (e) {
                                throw new Error('Resposta não é JSON: ' + text);
                            }
                        });
                    }).then(data => {
                        console.log('Resposta do servidor:', data); // Verifique a resposta do servidor
                        if (data.status === 'success') {
                            // Armazena informações do usuário na sessão
                            sessionStorage.setItem('userName', data.userName);
                            sessionStorage.setItem('userPhoto', data.userPhoto);
                            window.location.href = '../index.php'; // Redirecionar após o login bem-sucedido
                        } else {
                            console.error('Erro no login:', data.message);
                        }
                    }).catch(error => console.error('Erro ao enviar o token:', error));
                });
            }).catch((error) => {
                console.error('Erro ao autenticar:', error);
            });
        }


        document.getElementById('googleLoginWeb').addEventListener('click', handleGoogleLogin);
        document.getElementById('googleLoginMobile').addEventListener('click', handleGoogleLogin);
    </script>
    <script src="../assets/js/login-js/login-web.js"></script>
    <script src="../assets/js/login-js/login-mobile.js"></script>
    <script src="../assets/js/login-js/verificacao.js"></script>
    
</body>

</html>
