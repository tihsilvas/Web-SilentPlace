<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file']) && isset($_POST['action']) && $_POST['action'] === 'upload_image') {
    $userId = $_POST['user_id'];
    $file = $_FILES['file'];
    $uploadDir = 'uploads/';
    $uploadFile = $uploadDir . basename($file['name']);

    if (move_uploaded_file($file['tmp_name'], $uploadFile)) {
        $stmt = $pdo->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
        $stmt->execute([$uploadFile, $userId]);

        echo json_encode(['success' => true, 'imagePath' => $uploadFile]);
    } else {
        echo json_encode(['success' => false]);
    }
}
?>
