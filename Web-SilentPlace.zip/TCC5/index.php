<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/estilo-gerais.css">
    <link rel="stylesheet" href="assets/css/index.css">
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/animacoes.css">
    <title>Index</title>
</head>

<body>
    <header>
        <?php require_once 'includes/header.php'; ?>
    </header>
    <main>
        <div class="content1 fade-in">
            <div class="main-content">
                <div class="text-left">
                    <h1>Buscando o conforto e a praticidade</h1>
                    <h2 class="texto-index">Buscando ajudar você</h2>
                    <p class="texto-index">A Silent Place é uma empresa especializada em oferecer abafadores de som para pessoas tanto neurodivergentes quanto incomodadas. Nosso objetivo é proporcionar um ambiente mais tranquilo e confortável, ajudando a reduzir estímulos sonoros excessivos que podem causar desconforto.</p>

                    <button onclick="window.location.href='pages/sobre_nos.php';">Saiba mais</button>
                    <div class="bottom-content">
                        <img src="assets/img/index/abafador1.png" alt="Fone 1" data-src="assets/img/index/abafador1.png">
                        <img src="assets/img/index/abafador2.png" alt="Fone 2" data-src="assets/img/index/abafador2.png">
                        <img src="assets/img/index/abafador3.png" alt="Fone 3" data-src="assets/img/index/abafador3.png">
                    </div>
                </div>
                <div class="phone-right">
                    <div class="extras">
                        <img id="mainPhone" src="assets/img/index/abafador3.png" alt="Fone de ouvido">
                    </div>
                </div>
            </div>

        </div>
        <div class="content2 fade-in">
            <div class="left-side">
                <h1>NEURODIVERGÊNCIA</h1>
                <p>Neurodivergência é uma maneira de descrever como os cérebros funcionam de formas diferentes. Algumas
                    pessoas podem ser mais sensíveis a sons e luzes. <br>Compreender essas diferenças nos ajuda a criar
                    espaços mais acolhedores e confortáveis para todos.</p>
            </div>
            <div class="right-side">
                <img class="heart-img" src="assets/img/index/coracao.png" alt="Coração">
            </div>
        </div>
        <div class="content3 fade-in">
            <div class="left-side">
                <img src="assets/img/index/mao.jpg" alt="Imagem de Mão">
            </div>
            <div class="right-side">
                <img src="assets/img/index/logo.png" alt="Logo">
                <h1>BORA, FAZER PARTE <br>DESSA MISSÃO?</h1>
                <p>Na calçada movimentada, passos rápidos ecoam. O sol brilha alto, refletindo no asfalto quente. Risos
                    se misturam aos sons da cidade, enquanto pessoas de todas</p>
                <button class="button" onclick="window.location.href='pages/sobre_nos.php';">Saiba mais</button>
            </div>
        </div>
    </main>

    <footer>
        <?php require_once 'includes/footer.php'; ?>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.11.5/gsap.min.js"></script>
    <script>
        // Obtendo referência ao fone principal e às imagens de fones
        const mainPhone = document.getElementById('mainPhone');
        const bottomImages = document.querySelectorAll('.bottom-content img');

        // Função para alterar a imagem do fone principal com animação de arrastar
        function changeMainPhone(src) {
            // Cria uma nova imagem para o efeito de transição
            const newImage = document.createElement('img');
            newImage.src = src;
            newImage.style.position = 'absolute';
            newImage.style.top = '0';
            newImage.style.left = '100%'; // Começa fora da tela à direita
            newImage.style.width = '100%';
            newImage.style.height = 'auto';
            newImage.style.transition = 'transform 0.8s ease';
            mainPhone.parentElement.appendChild(newImage);

            // Animação de arrastar
            gsap.to(mainPhone, {
                duration: 0.8,
                xPercent: 600, // Move a imagem atual para fora da tela à esquerda
                ease: 'power2.inOut',
                onComplete: () => {
                    mainPhone.src = src;
                    gsap.set(mainPhone, {
                        xPercent: 100
                    }); // Reposiciona a imagem atual para fora da tela à direita

                    gsap.to(newImage, {
                        duration: 0.2,
                        xPercent: 0, // Move a nova imagem para o lugar da antiga
                        ease: 'power2.inOut',
                        onComplete: () => {
                            gsap.set(mainPhone, {
                                xPercent: 0
                            });
                            newImage.remove(); // Remove a nova imagem após a animação
                        }
                    });
                }
            });
        }

        // Adiciona event listeners às imagens de fones na parte inferior
        bottomImages.forEach(img => {
            img.addEventListener('click', (event) => {
                const newSrc = event.target.getAttribute('data-src');
                changeMainPhone(newSrc);
                resetAutoRotation(); // Reinicia o intervalo de troca automática
            });
        });

        // Função para alternar a imagem do fone principal a cada 4 segundos
        let currentIndex = 0;
        const phoneImages = ['assets/img/index/abafador1.png', 'assets/img/index/abafador2.png', 'assets/img/index/abafador3.png'];
        let rotationInterval;

        function rotateMainPhone() {
            currentIndex = (currentIndex + 1) % phoneImages.length;
            changeMainPhone(phoneImages[currentIndex]);
        }

        function startAutoRotation() {
            rotationInterval = setInterval(rotateMainPhone, 4000); // Alterna a cada 4 segundos
        }

        function resetAutoRotation() {
            clearInterval(rotationInterval); // Limpa o intervalo atual
            startAutoRotation(); // Reinicia o intervalo
        }

        startAutoRotation(); // Inicia o intervalo de rotação automática quando a página é carregada
    </script>
    <script src="assets/js/animacao.js"></script>
</body>

</html>