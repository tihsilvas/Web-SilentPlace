CREATE DATABASE SILENTPLACE;
USE SILENTPLACE;

CREATE TABLE `tb_usuario` (
  `id_usuario` INT PRIMARY KEY AUTO_INCREMENT COMMENT 'Identificador único do usuário, gerado automaticamente.',
  `email_usuario` VARCHAR(256) NOT NULL COMMENT 'Endereço de e-mail do usuário, usado para autenticação e comunicação.',
  `senha_usuario` VARCHAR(256) NOT NULL COMMENT 'Senha do usuário, armazenada de forma criptografada para segurança.',
  `nome_usuario` VARCHAR(50) NOT NULL COMMENT 'Nome completo do usuário.',
  `foto_usuario` VARCHAR(255) DEFAULT NULL COMMENT 'URL ou caminho para a foto do perfil do usuário. Pode ser nulo se o usuário não optar por fornecer uma foto.',
  `sense_auditiva_usuario` BOOLEAN COMMENT 'Indica se o usuário possui deficiência auditiva (TRUE) ou não (FALSE).'
);

CREATE TABLE `tb_pedido` (
  `id_pedido` INT PRIMARY KEY AUTO_INCREMENT COMMENT 'Identificador único do pedido, gerado automaticamente.',
  `dt_pedido` DATE NOT NULL COMMENT 'Data em que o pedido foi realizado.',
  `total_pedido` DECIMAL(10, 2) NOT NULL COMMENT 'Valor total do pedido, incluindo todos os produtos e taxas.',
  `status_pedido` VARCHAR(50) NOT NULL COMMENT 'Status atual do pedido, como "Pendente", "Em Processamento", "Concluído", etc.',
  `id_usuario` INT COMMENT 'Identificador do usuário que fez o pedido. Relacionado ao `id_usuario` na tabela `tb_usuario`.',
  FOREIGN KEY (`id_usuario`) REFERENCES `tb_usuario`(`id_usuario`) COMMENT 'Relacionamento com a tabela `tb_usuario` para associar o pedido ao usuário.'
);

CREATE TABLE `tb_produto` (
  `id_produto` INT PRIMARY KEY AUTO_INCREMENT COMMENT 'Identificador único do produto, gerado automaticamente.',
  `nome_produto` VARCHAR(100) NOT NULL COMMENT 'Nome do produto.',
  `descricao_produto` TEXT COMMENT 'Descrição detalhada do produto, podendo incluir informações adicionais como características e benefícios.',
  `preco_produto` DECIMAL(10, 2) NOT NULL COMMENT 'Preço do produto, incluindo a unidade monetária.'
);

CREATE TABLE `tb_compra` (
  `id_compra` INT PRIMARY KEY AUTO_INCREMENT COMMENT 'Identificador único da compra, gerado automaticamente.',
  `dt_compra` DATE NOT NULL COMMENT 'Data em que a compra foi realizada.',
  `total_compra` DECIMAL(10, 2) NOT NULL COMMENT 'Valor total da compra, incluindo todos os produtos e taxas.',
  `id_usuario` INT COMMENT 'Identificador do usuário que fez a compra. Relacionado ao `id_usuario` na tabela `tb_usuario`.',
  FOREIGN KEY (`id_usuario`) REFERENCES `tb_usuario`(`id_usuario`) COMMENT 'Relacionamento com a tabela `tb_usuario` para associar a compra ao usuário.'
);

CREATE TABLE `tb_retirada` (
  `id_retirada` INT PRIMARY KEY AUTO_INCREMENT COMMENT 'Identificador único da retirada, gerado automaticamente.',
  `cod_retirada` VARCHAR(50) NOT NULL COMMENT 'Código único para identificar a retirada.',
  `dt_retirada` DATE NOT NULL COMMENT 'Data em que a retirada foi realizada.',
  `id_compra` INT COMMENT 'Identificador da compra associada à retirada. Relacionado ao `id_compra` na tabela `tb_compra`.',
  FOREIGN KEY (`id_compra`) REFERENCES `tb_compra`(`id_compra`) COMMENT 'Relacionamento com a tabela `tb_compra` para associar a retirada à compra.'
);

CREATE TABLE `tb_maquina` (
  `id_maquina` INT PRIMARY KEY AUTO_INCREMENT COMMENT 'Identificador único da máquina, gerado automaticamente.',
  `local_maquina` VARCHAR(100) NOT NULL COMMENT 'Localização ou descrição da máquina.'
);

CREATE TABLE `tb_pedido_produto` (
  `id_pedido` INT COMMENT 'Identificador do pedido. Relacionado ao `id_pedido` na tabela `tb_pedido`.',
  `id_produto` INT COMMENT 'Identificador do produto. Relacionado ao `id_produto` na tabela `tb_produto`.',
  `quantidade` INT NOT NULL COMMENT 'Quantidade do produto no pedido.',
  PRIMARY KEY (`id_pedido`, `id_produto`) COMMENT 'Chave primária composta que garante a unicidade da combinação pedido-produto.',
  FOREIGN KEY (`id_pedido`) REFERENCES `tb_pedido`(`id_pedido`) COMMENT 'Relacionamento com a tabela `tb_pedido`.',
  FOREIGN KEY (`id_produto`) REFERENCES `tb_produto`(`id_produto`) COMMENT 'Relacionamento com a tabela `tb_produto`.'
);

CREATE TABLE `tb_compra_produto` (
  `id_compra` INT COMMENT 'Identificador da compra. Relacionado ao `id_compra` na tabela `tb_compra`.',
  `id_produto` INT COMMENT 'Identificador do produto. Relacionado ao `id_produto` na tabela `tb_produto`.',
  `quantidade` INT NOT NULL COMMENT 'Quantidade do produto na compra.',
  PRIMARY KEY (`id_compra`, `id_produto`) COMMENT 'Chave primária composta que garante a unicidade da combinação compra-produto.',
  FOREIGN KEY (`id_compra`) REFERENCES `tb_compra`(`id_compra`) COMMENT 'Relacionamento com a tabela `tb_compra`.',
  FOREIGN KEY (`id_produto`) REFERENCES `tb_produto`(`id_produto`) COMMENT 'Relacionamento com a tabela `tb_produto`.'
);

CREATE TABLE `tb_maquina_retirada` (
  `id_maquina` INT COMMENT 'Identificador da máquina. Relacionado ao `id_maquina` na tabela `tb_maquina`.',
  `id_retirada` INT COMMENT 'Identificador da retirada. Relacionado ao `id_retirada` na tabela `tb_retirada`.',
  PRIMARY KEY (`id_maquina`, `id_retirada`) COMMENT 'Chave primária composta que garante a unicidade da combinação máquina-retrada.',
  FOREIGN KEY (`id_maquina`) REFERENCES `tb_maquina`(`id_maquina`) COMMENT 'Relacionamento com a tabela `tb_maquina`.',
  FOREIGN KEY (`id_retirada`) REFERENCES `tb_retirada`(`id_retirada`) COMMENT 'Relacionamento com a tabela `tb_retirada`.'
);
