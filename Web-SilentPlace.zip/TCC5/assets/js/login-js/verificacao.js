const signInButton = document.getElementById('signIn');
const signUpButton = document.getElementById('signUp');
const loginButton = document.getElementById('loginButton');
const registerButton = document.getElementById('registerButton');
const email = document.getElementById('email');
const password = document.getElementById('password');
const regEmail = document.getElementById('regEmail');
const regPassword = document.getElementById('regPassword');
const confirmPassword = document.getElementById('confirmPassword');
const username = document.getElementById('username');

const emailError = document.getElementById('emailError');
const passwordError = document.getElementById('passwordError');
const regEmailError = document.getElementById('regEmailError');
const regPasswordError = document.getElementById('regPasswordError');
const confirmPasswordError = document.getElementById('confirmPasswordError');
const usernameError = document.getElementById('usernameError');

const acceptTerms = document.getElementById('acceptTerms');

// Função de validação do formulário de login
email.addEventListener('input', validateLoginForm);
password.addEventListener('input', validateLoginForm);

// Função de validação do formulário de cadastro
regEmail.addEventListener('input', validateRegisterForm);
regPassword.addEventListener('input', validateRegisterForm);
confirmPassword.addEventListener('input', validateRegisterForm);
username.addEventListener('input', validateRegisterForm);

// Função para validar e-mails
function validateEmail(email) {
    const re = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    return re.test(email);
}

// Função de validação do formulário de login
function validateLoginForm() {
    const isValidEmail = validateEmail(email.value);
    const isValidPassword = password.value.length >= 6;
    const isTermsAccepted = acceptTerms.checked;  // Verifica se os termos foram aceitos

    // Esconde todos os erros inicialmente
    emailError.style.display = 'none';
    passwordError.style.display = 'none';

    // Exibe os erros para campos inválidos
    if (!isValidEmail) {
        email.classList.add('invalid');
        emailError.style.display = 'block';
    } else {
        email.classList.remove('invalid');
        email.classList.add('valid');
    }

    if (!isValidPassword) {
        password.classList.add('invalid');
        passwordError.style.display = 'block';
    } else {
        password.classList.remove('invalid');
        password.classList.add('valid');
    }

    // O botão de login só será habilitado se o email, a senha estiverem válidos e os termos forem aceitos
    loginButton.disabled = !(isValidEmail && isValidPassword && isTermsAccepted);
}

// Função de validação do formulário de registro
function validateRegisterForm() {
    const isValidUsername = username.value.trim() !== '';
    const isValidEmail = validateEmail(regEmail.value);
    const isValidPassword = regPassword.value.length >= 6;
    const isPasswordMatch = regPassword.value === confirmPassword.value;
    const isTermsAccepted = acceptTerms.checked; // Verifica se os termos foram aceitos

    // Esconde todos os erros inicialmente
    usernameError.style.display = 'none';
    regEmailError.style.display = 'none';
    regPasswordError.style.display = 'none';
    confirmPasswordError.style.display = 'none';

    // Exibe os erros para campos inválidos
    if (!isValidUsername) {
        username.classList.add('invalid');
        usernameError.style.display = 'block';
    } else {
        username.classList.remove('invalid');
        username.classList.add('valid');
    }

    if (!isValidEmail) {
        regEmail.classList.add('invalid');
        regEmailError.style.display = 'block';
    } else {
        regEmail.classList.remove('invalid');
        regEmail.classList.add('valid');
    }

    if (!isValidPassword) {
        regPassword.classList.add('invalid');
        regPasswordError.style.display = 'block';
    } else {
        regPassword.classList.remove('invalid');
        regPassword.classList.add('valid');
    }

    if (!isPasswordMatch) {
        confirmPassword.classList.add('invalid');
        confirmPasswordError.style.display = 'block';
    } else {
        confirmPassword.classList.remove('invalid');
        confirmPassword.classList.add('valid');
    }

    if (!isTermsAccepted) {
        acceptTerms.idList.add('invalid');
        acceptTermsError.style.display = 'block';
    } else {
        acceptTerms.idList.remove('invalid');
        acceptTermsError.classList.add('valid');
    }

    // O botão de registro só será habilitado se todos os campos forem válidos e os termos forem aceitos
    registerButton.disabled = !(isValidUsername && isValidEmail && isValidPassword && isPasswordMatch && isTermsAccepted);
}

// Função para habilitar o botão de login e de registro quando a caixa de seleção dos termos for marcada
acceptTerms.addEventListener('change', function () {
    validateLoginForm();   // Verifica e atualiza o estado do botão de login
    validateRegisterForm(); // Verifica e atualiza o estado do botão de registro
});
