function toggleMobileForm() {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const isLoginFormVisible = loginForm.style.transform === 'translateY(0px)' || !loginForm.style.transform;

    if (isLoginFormVisible) {
        loginForm.style.transform = 'translateY(100%)';
        loginForm.style.opacity = '0';
        registerForm.style.transform = 'translateY(0)';
        registerForm.style.opacity = '1';
    } else {
        loginForm.style.transform = 'translateY(0)';
        loginForm.style.opacity = '1';
        registerForm.style.transform = 'translateY(-100%)';
        registerForm.style.opacity = '0';
    }
}