const signUpOverlayButton = document.getElementById('signUpOverlay');
const signInOverlayButton = document.getElementById('signInOverlay');
const container = document.querySelector('.container');

function toggleForms() {
    container.classList.toggle('right-panel-active');
}

function updateOverlayText() {
    if (container.classList.contains('right-panel-active')) {
        signUpOverlayButton.innerText = 'Logar-se';
        signInOverlayButton.innerText = 'Logar-se';
        document.querySelector('.overlay-right h1').textContent = 'Sou Membro';
    } else {
        signUpOverlayButton.innerText = 'Cadastre-se';
        signInOverlayButton.innerText = 'Cadastre-se';
        document.querySelector('.overlay-right h1').textContent = 'Ser Membro';
    }
}

signUpOverlayButton.addEventListener('click', () => {
    toggleForms();
    updateOverlayText();
});

signInOverlayButton.addEventListener('click', () => {
    toggleForms();
    updateOverlayText();
});