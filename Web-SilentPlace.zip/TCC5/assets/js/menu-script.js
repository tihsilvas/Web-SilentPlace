document.addEventListener('DOMContentLoaded', function () {
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    const closeBtn = document.getElementById('closeBtn');
    const body = document.body;

    menuToggle.addEventListener('click', function () {
        sidebar.classList.remove('hidden');
        sidebar.classList.add('menu-open');
        body.classList.add('menu-open');
    });

    closeBtn.addEventListener('click', function () {
        sidebar.classList.remove('menu-open');
        sidebar.classList.add('hidden');
        body.classList.remove('menu-open');
    });
});