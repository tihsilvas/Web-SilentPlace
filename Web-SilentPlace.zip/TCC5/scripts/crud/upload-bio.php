<?php
session_start();

include "../includes/conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["bio_text"])) {
        $bio_text = $_POST["bio_text"];
        $email = $_SESSION['email'] ?? '';

        // Atualiza apenas a biografia do usuário com o email correspondente
        $sql = "UPDATE tb_usuario SET bio_usuario = '$bio_text' WHERE email_usuario = '$email'";
        if ($conn->query($sql) === TRUE) {
            header("Location: ../perfil.php");
            exit();
        } else {
            echo "Erro ao atualizar a biografia: " . $conn->error;
        }
    } else {
        $_SESSION['campo_vazio'] = true;
        header("Location: ../perfil.php");
        exit();
    }
}
$conn->close();
