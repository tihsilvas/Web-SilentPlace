<?php
session_start();
include "../includes/conexao.php";
require_once '../criptografia/criptografar.php';

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (!empty($_GET["novo_email"])) {
        $novo_email = $_GET["novo_email"];
        $email_logado = $_SESSION['email'] ?? '';

        // Criptografa o novo email
        $email_novo_criptografado = encryptData($novo_email, $key);

        // Atualiza apenas o email do usuário logado
        $sql_email = "UPDATE tb_usuario SET email_usuario = '$email_novo_criptografado' WHERE email_usuario = '$email_logado'";
        if ($conn->query($sql_email) === TRUE) {
            header("Location: sucesso-email.php");
            exit();
        } else {
            echo "Erro ao atualizar o Email: " . $conn->error;
        }
    } else {
        echo "Novo email não foi fornecido";
    }
} else {
    echo "Método de requisição inválido";
    exit();
}
$conn->close();
