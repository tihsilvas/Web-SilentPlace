<?php
require_once '../../includes/conexao.php';
require_once '../../criptografia/descriptografar.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["txt_senha"]) && !empty($_POST["txt_email"]) && !empty($_POST["txt_nome"])) {
        $senha = $_POST["txt_senha"];
        $email = $_POST["txt_email"];
        $nome = $_POST["txt_nome"];

        require_once '../../criptografia/criptografar.php';

        $senha_criptografada = encryptData($senha, $key);
        $email_criptografado = encryptData($email, $key);

        // Descriptografar emails do banco de dados
        $query = "SELECT * FROM tb_usuario";
        $result = mysqli_query($conn, $query);
        $usuarios = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $usuario = array(
                "nome" => $row['nome_usuario'],
                "email" => decryptData($row['email_usuario'], $key),
                "senha" => $row['senha_usuario']
            );
            $usuarios[] = $usuario;
        }

        // Comparar o email fornecido pelo usuário com os emails descriptografados do banco de dados
        foreach ($usuarios as $usuario) {
            if ($usuario["email"] === $email) {
                // Se já existe um usuário com o mesmo email, redirecionar de volta para a página de cadastro com um alerta
                echo "<script>alert('Já existe um usuário com este email!');</script>";
                echo "<script>window.location.href = 'login.php';</script>";
                exit;
            }
        }

        // Se não existe um usuário com o mesmo email, inserir no banco de dados
        $sql = "INSERT INTO tb_usuario (nome_usuario, email_usuario, senha_usuario) VALUES ('$nome', '$email_criptografado', '$senha_criptografada')";
        $result_insert = mysqli_query($conn, $sql);
        header("Location: efetuado.html");
        exit;
    }
}
