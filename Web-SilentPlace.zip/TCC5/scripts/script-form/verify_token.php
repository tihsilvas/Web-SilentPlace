<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idToken = $_POST['idToken'];

    // Substitua 'YOUR_API_KEY' pela sua chave da API do Firebase
    $apiKey = 'AIzaSyAJ_jK7lXhkXCT9Xok9QssQ28jtkhaj_Yo';
    $url = "https://identitytoolkit.googleapis.com/v1/accounts:lookup?key={$apiKey}";

    // Configuração cURL para enviar a solicitação
    $ch = curl_init($url);

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(['idToken' => $idToken]));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/x-www-form-urlencoded'
    ]);

    $response = curl_exec($ch);

    if ($response === false) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Erro ao acessar o serviço Firebase: ' . curl_error($ch)
        ]);
        curl_close($ch);
        exit;
    }

    curl_close($ch);

    $data = json_decode($response, true);

    header('Content-Type: application/json');

    if (isset($data['users'][0])) {
        $user = $data['users'][0];
        $_SESSION['userName'] = $user['displayName'];
        $_SESSION['userPhoto'] = $user['photoUrl'];
        $_SESSION['userEmail'] = $user['email']; // Salva o e-mail na sessão

        echo json_encode([
            'status' => 'success',
            'userName' => $user['displayName'],
            'userPhoto' => $user['photoUrl'],
            'userEmail' => $user['email'] // Retorna o e-mail na resposta
        
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Token inválido'
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Método não permitido'
    ]);
}
?>
