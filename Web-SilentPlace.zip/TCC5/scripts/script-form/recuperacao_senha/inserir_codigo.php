<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../../../assets/css/estilo-gerais.css">
    <link rel="stylesheet" href="recuperar.css">
    <link rel="stylesheet" href="../../../assets/css/voltar-icone.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="icon" href="img/battle.ico" type="image/x-icon">
    <title>Inserir Código de Verificação</title>
</head>

<body>
    <a href="inserir_email.html" class="back-icon"><i class="fas fa-arrow-left"></i></a>
    <div class="form-wrapper">
        <h1 class="titulo">Código de Verificação</h1>
        <form action="verificar_codigo.php" method="POST">
            <label for="txt_codigo">Informe o código de verificação:</label><br>
            <input type="text" id="txt_codigo" name="txt_codigo" required oninput="checkInputLength()"><br><br>
            <input type="submit" value="Verificar Código" id="submit_button" disabled>
            <input type="hidden" name="email" value="<?php echo $_SESSION['email']; ?>">
        </form>
    </div>

    <script>
        function checkInputLength() {
            const input = document.getElementById('txt_codigo');
            const submitButton = document.getElementById('submit_button');

            if (input.value.length === 6) {
                // Enable the button if exactly 6 characters
                submitButton.classList.add('active');
                submitButton.disabled = false;
            } else {
                // Disable the button otherwise
                submitButton.classList.remove('active');
                submitButton.disabled = true;
            }
        }

        // Initialize the button state based on the current input value on page load
        document.addEventListener('DOMContentLoaded', checkInputLength);
    </script>
</body>

</html>