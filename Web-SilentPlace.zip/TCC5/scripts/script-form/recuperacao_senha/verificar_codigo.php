<?php
session_start();
require_once "../../../includes/conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['txt_codigo']) && isset($_POST['email'])) {
        $codigo_digitado = $_POST['txt_codigo'];
        $email = $_POST['email'];

        if ($codigo_digitado === $_SESSION['codigo_verificacao']) {
            header("Location: senha_acesso.php?email=" . urlencode($email));
            exit();
        } else {
            echo '<script>alert("Código de verificação incorreto!"); window.history.back();</script>';
        }
    }
}
