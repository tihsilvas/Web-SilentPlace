<?php
session_start();  // Inicia a sessão

require '../../vendor/autoload.php';  // Carregar PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Recuperando o e-mail da sessão (caso tenha sido armazenado)
$email = $_SESSION['email_descriptografado'] ?? $_SESSION['userEmail'] ?? '';  // Ajuste a chave conforme necessário

if ($email) {
    try {
        $codigoVerificacao = '6978';  // Código fixo

        // Configuração do PHPMailer
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';  // Servidor SMTP do Gmail
        $mail->SMTPAuth = true;
        $mail->Username = 'contact.silentplace@gmail.com';  // Seu e-mail
        $mail->Password = 'jubj fbah lrvo fzco';  // Senha de app gerada
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        $mail->CharSet = 'UTF-8';

        $mail->setFrom('contact.silentplace@gmail.com', 'Silent Place');
        $mail->addAddress($email);  // E-mail do usuário recuperado da sessão

        $mail->isHTML(true);
        $mail->Subject = 'Código de Verificação';
        $mail->Body    = "Seu código de verificação é: <strong>$codigoVerificacao</strong>";

        // Enviar o e-mail
        $mail->send();

        echo 'Código enviado com sucesso!';

        // Após o envio, redireciona para a página inicial (home)
        header("Location: ../../index.php");  
        exit();  // Certifique-se de sair após o redirecionamento
    } catch (Exception $e) {
        echo "Erro ao enviar e-mail: {$e->getMessage()}";
    }
} else {
    echo "E-mail não encontrado na sessão.";
}
?>
