<?php
session_start();
require_once '../../includes/conexao.php';
require_once '../../criptografia/descriptografar.php';

header('Content-Type: application/json');

// Verifica se o usuário está logado
if (!isset($_SESSION['email'])) {
    echo json_encode(['success' => false, 'error' => 'Usuário não autenticado.']);
    exit;
}

// Recebe os dados enviados via POST
$data = json_decode(file_get_contents('php://input'), true);
$password = $data['password'] ?? '';
$field = $data['field'] ?? '';

// Recupera o e-mail do usuário logado
$email = $_SESSION['email'];

// Recupera os dados do usuário pelo e-mail
$query = $pdo->prepare("SELECT * FROM tb_usuario WHERE email_usuario = :email");
$query->bindParam(':email', $email);
$query->execute();
$user = $query->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo json_encode(['success' => false, 'error' => 'Usuário não encontrado.']);
    exit;
}

// Verifica se a senha informada corresponde à senha armazenada
if (password_verify($password, $user['senha_usuario'])) {
    $decryptedContent = '';

    // Descriptografa o campo selecionado
    switch ($field) {
        case 'email':
            $decryptedContent = decryptData($user['email_usuario'], "chave_secreta");
            break;
        case 'nome':
            $decryptedContent = decryptData($user['nome_usuario'], "chave_secreta");
            break;
        default:
            echo json_encode(['success' => false, 'error' => 'Campo inválido.']);
            exit;
    }

    echo json_encode(['success' => true, 'decryptedContent' => $decryptedContent]);
} else {
    echo json_encode(['success' => false, 'error' => 'Senha incorreta.']);
}
?>
