 // Função para limpar o chat
 function clearChat() {
    var chatMessages = document.getElementById('chat-messages');
    chatMessages.innerHTML = '';
    chatMessages.innerHTML = '<div class="message bot-message">Olá! Eu sou o ChatBot da Battle to Health. Para continuar nossa conversa, por favor, selecione uma das opções abaixo:</div>';
}

// Função para enviar uma pergunta
function sendQuestion(question) {
    appendMessage('user', question);
    appendTypingIndicator();

    setTimeout(function() {
        var botResponse = getBotResponse(question);
        appendMessage('bot', botResponse);
        removeTypingIndicator(); 
    }, 1000);
}

// Função para adicionar a mensagem de digitação
function appendTypingIndicator() {
    var chatMessages = document.getElementById('chat-messages');
    var typingIndicator = document.createElement('div');
    typingIndicator.className = 'message bot-message typing-indicator';
    typingIndicator.innerHTML = '<p class="message-text typing-animation">Digitando...</p>';
    chatMessages.appendChild(typingIndicator);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Função para remover a mensagem de digitação
function removeTypingIndicator() {
    var chatMessages = document.getElementById('chat-messages');
    var typingIndicator = chatMessages.querySelector('.typing-indicator');
    if (typingIndicator) {
        chatMessages.removeChild(typingIndicator);
    }
}

// Função para adicionar uma mensagem ao chat
function appendMessage(sender, message) {
    var chatMessages = document.getElementById('chat-messages');
    var messageDiv = document.createElement('div');
    messageDiv.className = 'message ' + sender + '-message';
    var messageText = document.createElement('p');
    messageText.className = 'message-text';
    messageText.textContent = message;
    messageDiv.appendChild(messageText);

    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function getBotResponse(userInput) {
    switch(userInput) {
        case 'O que é neurodivergência e como ela afeta as pessoas?':
            return 'Neurodivergência é um termo usado para descrever variações naturais no funcionamento do cérebro humano, como o autismo, o TDAH, a dislexia, entre outros. Essas diferenças podem afetar o comportamento, a aprendizagem e a forma como as pessoas interagem com o mundo ao seu redor.';
        case 'Quais são as características do autismo?':
            return 'O autismo é um espectro de condições caracterizado por dificuldades em comunicação social e padrões de comportamento repetitivos ou restritos.';
        case 'Como o TDAH impacta a vida de uma pessoa?':
            return 'O TDAH pode afetar a capacidade de uma pessoa se concentrar, controlar impulsos e organizar tarefas.';
        case 'O que é a dislexia e como ela afeta a aprendizagem?':
            return 'A dislexia é um transtorno de aprendizagem que afeta a leitura, escrita e soletração.';
        case 'Quais são as dificuldades enfrentadas por pessoas com síndrome de Asperger?':
            return 'A síndrome de Asperger pode causar dificuldades em áreas como comunicação social e compreensão de normas sociais.';
        default:
            return 'Desculpe, não entendi a sua pergunta. Tente perguntar de outra forma.';
    }
}