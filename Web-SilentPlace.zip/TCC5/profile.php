<?php
// Verifica se a sessão já foi iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'includes/conexao.php';
require_once 'criptografia/descriptografar.php';

// Variáveis padrão
$nomeUsuario = "";
$profileImg = "assets/img/logo.png";
$senseAuditiva = false;
$obscuredEmail = "";
$maskedPassword = "********";
$isFirebaseUser = false;

// Verificação de login Firebase
if (isset($_SESSION['userName'], $_SESSION['userPhoto'])) {
    $isFirebaseUser = true;
    $nomeUsuario = $_SESSION['userName'];
    $profileImg = $_SESSION['userPhoto'];
    $obscuredEmail = "*********@gmail.com"; // Opcional
} else {
    // Verificação de login convencional
    if (!isset($_SESSION['email'])) {
        die("Usuário não autenticado.");
    }

    // Obtém o e-mail do usuário logado a partir da sessão
    $email = $_SESSION['email'];

    // Consultar o banco de dados para obter os dados do usuário com o e-mail fornecido
    $query = "SELECT * FROM tb_usuario WHERE email_usuario = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    // Verifica se o usuário foi encontrado
    if ($row = mysqli_fetch_assoc($result)) {
        // Descriptografar os dados
        $decryptedEmail = decryptData($row['email_usuario'], "chave_secreta");
        $obscuredEmail = obscureEmail($decryptedEmail);

        $nomeUsuario = $row['nome_usuario'] ?? "Usuário";
        $profileImg = $row['foto_usuario'] ?? $profileImg; // Usar imagem padrão se não houver
        $senseAuditiva = isset($row['sense_auditiva_usuario']) ? $row['sense_auditiva_usuario'] : false;
    } else {
        die("Usuário não encontrado.");
    }
    $conn->close();
}

// Função para ocultar e-mail com asteriscos
function obscureEmail($email)
{
    $parts = explode('@', $email);
    if (count($parts) == 2) {
        $name = substr($parts[0], 0, 1) . str_repeat('*', strlen($parts[0]) - 1);
        return $name . '@' . $parts[1];
    }
    return $email;
}

$userName = isset($_SESSION['userName']) ? $_SESSION['userName'] : '';

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil do Usuário e ChatBot</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/css/perfil.css">
</head>

<body>
    <header>
        <?php require_once 'includes/header.php'; ?>
    </header>

    <main style="background-color: #E5E7EB; padding-bottom: 20px">
        <!-- Perfil do Usuário -->
        <div class="perfil-container">
            <div class="perfil-principal">
                <!-- Cartão de Perfil -->
                <div class="perfil-card">
                    <div class="profile-container">
                        <img id="profileImg" alt="Foto de perfil de <?php echo htmlspecialchars($nomeUsuario); ?>" class="profile-img" src="<?php echo $profileImg; ?>" />
                    </div>
                    <h2 class="perfil-nome" style="color: #444444;">
                        <?php
                        echo htmlspecialchars($nomeUsuario ? $nomeUsuario : $userName);
                        ?></h2>
                    <p class="perfil-descricao">Usuário Silent Place</p>
                    <p class="perfil-localizacao">São Paulo</p>
                </div>

                <!-- Detalhes do Usuário -->
                <div class="perfil-detalhes">
                    <div class="editable-field">
                        <span class="field-label">Nome:</span>
                        <p class="field-content">
                            <?php
                            echo htmlspecialchars($nomeUsuario ? $nomeUsuario : $userName);
                            ?>
                        </p>
                    </div>
                    <div class="editable-field">
                        <span class="field-label">E-mail:</span>
                        <p class="field-content"><?php echo $obscuredEmail; ?></p>
                    </div>
                    <div class="editable-field">
                        <span class="field-label">Senha:</span>
                        <p class="field-content disabled-field"><?php echo $maskedPassword; ?></p>
                    </div>
                    <div class="editable-field">
                        <span class="field-label">Auditiva:</span>
                        <p class="field-content"><?php echo $senseAuditiva ? 'Sim' : 'Não'; ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- ChatBot -->
        <div class="chat-container">
            <div class="chat-header">
                <center>
                    <p class="text-lg">ChatBot - Neurodivergência</p>
                </center>
            </div>
            <div class="chat-messages" id="chat-messages">
                <div class="message bot-message">Olá! Eu sou o ChatBot da Battle to Health. Para continuar nossa conversa, por favor, selecione uma das opções abaixo:</div>
            </div>
            <div class="chat-options">
                <button class="option-button" onclick="sendQuestion('O que é neurodivergência e como ela afeta as pessoas?')">O que é neurodivergência e como ela afeta as pessoas?</button>
                <button class="option-button" onclick="sendQuestion('Quais são as características do autismo?')">Quais são as características do autismo?</button>
                <button class="option-button" onclick="sendQuestion('Como o TDAH impacta a vida de uma pessoa?')">Como o TDAH impacta a vida de uma pessoa?</button>
                <button class="option-button" onclick="sendQuestion('O que é a dislexia e como ela afeta a aprendizagem?')">O que é a dislexia e como ela afeta a aprendizagem?</button>
                <button class="option-button" onclick="sendQuestion('Quais são as dificuldades enfrentadas por pessoas com síndrome de Asperger?')">Quais são as dificuldades enfrentadas por pessoas com síndrome de Asperger?</button>
            </div>
        </div>
    </main>
    <footer>
        <?php require_once 'includes/footer.php'; ?>
    </footer>
    <script src="scripts/script-profile/chat.js"></script>
</body>

</html>