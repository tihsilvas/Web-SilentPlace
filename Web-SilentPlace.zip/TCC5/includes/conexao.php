<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "silentplace";
$porta = 3306;

$conn = mysqli_connect($servidor, $usuario, $senha, $banco, $porta);

if (!$conn) {
    die("Erro ao conectar com o servidor!");
}
