<?php
if (!defined('BASE_URL')) {
    define('BASE_URL', '/TCC5/'); //Move ao Diretório Raiz
}
?>