<?php
require_once "root_directory.php"; 

$isUserLoggedIn = true; 

if (isset($_SESSION['logado']) && $_SESSION['logado'] === true) {
    $isUserLoggedIn = true; 
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer Exemplo</title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/estilo-gerais.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/footer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>

    <footer>
        <!-- Seção 1: Logo -->
        <div class="footer-section logo">
            <img src="<?php echo BASE_URL; ?>assets/img/logo-texto.png" alt="Logo Silent Place">
        </div>

        <!-- Seção 2: Redes Sociais -->
        <div class="footer-section social-icons">
            <h4>Redes Sociais</h4>
            <p>Acompanhe a Silent Place nas Redes Sociais</p>
            <div class="icones">
                <a href="https://facebook.com" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a>
                <a href="https://twitter.com" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a>
                <a href="https://instagram.com" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a>
            </div>
        </div>

        <!-- Seção 3: Informações -->
        <div class="footer-section information">
            <h4 style="margin-left: 15px;">Informações</h4>
            <p class="gray"><a href="#abafadores">Abafadores</a></p>
            <p class="gray"><a href="#about">Sobre Nós</a></p>
            <p class="gray"><a href="#locations">Localidades</a></p>
            <?php if ($isUserLoggedIn): ?>
                <p class="gray">
                    <a href="<?php echo BASE_URL; ?>logout.php" class="logout-text">Encerrar Sessão</a>
                </p>
            <?php endif; ?>
        </div>

        <!-- Seção 4: Newsletter e Copyright -->
        <div class="footer-section footer-section-distance">
            <div class="newsletter">
                <h4>Inscreva-se</h4>
                <p class="newsletter-description">Insira seu e-mail para ficar por dentro das novidades!</p>
                <input type="email" placeholder="Seu e-mail">
                <button type="submit" onclick="enviarMensagem()">Inscrever</button>
            </div>
            <div class="copyright">
                <p>&copy; Copyright Silent Place 2024. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    <script>
        function enviarMensagem() {
            alert("Enviado com sucesso!");
        }
    </script>
</body>

</html>
