<?php
// Verifica se a sessão já foi iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once "root_directory.php";

if (isset($_GET['logout']) && $_GET['logout'] == 1) {
    unset($_SESSION['logado'], $_SESSION['username']);
    header('Location: ' . BASE_URL . 'assets/img/user.png');
    exit();
}

$loginStatus = isset($_SESSION['logado']) && $_SESSION['logado'] === true;
$nomeUsuario = $_SESSION['nome'] ?? "";
$foto_usuario = $_SESSION['foto'] ?? BASE_URL . 'assets/img/user.png';

// echo 'Status de login: ' . $loginStatus . '<br>';
// echo 'Nome do usuário da sessão: ' . $_SESSION['nome'] . '<br>';
// echo 'Email da sessão: ' . $_SESSION['email'] . '<br>';

if (empty($nomeUsuario) && $loginStatus) {
    $email = $_SESSION['email'] ?? '';

    $conn = mysqli_connect($servidor, $usuario, $senha, $banco, $porta);
    $query = "SELECT nome_usuario, foto_usuario FROM tb_usuario WHERE email_usuario = '$email'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nomeUsuario = $row['nome_usuario'];
        $_SESSION['username'] = $nomeUsuario;
        $foto_usuario = $row['foto_usuario'];

        if (empty($foto_usuario)) {
            $foto_usuario = BASE_URL . 'assets/img/user.png';
        }
    }
    $sql = "SELECT bio_usuario FROM tb_usuario WHERE email_usuario = '$email'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $bio_usuario = $row['bio_usuario'];
    } else {
        $bio_usuario = "Nenhuma biografia encontrada.";
    }

    $conn->close();
}
/* Login com o Google*/
$userName = isset($_SESSION['userName']) ? $_SESSION['userName'] : '';
$userPhoto = isset($_SESSION['userPhoto']) ? $_SESSION['userPhoto'] : '';
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/estilo-gerais.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/header.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Header</title>
</head>

<body>
    <header class="site-header">
        <div id="menuToggle" class="menu-toggle">
            <img src="<?php echo BASE_URL; ?>assets/img/menu.png">
        </div>

        <a href="<?php echo BASE_URL; ?>index.php" class="logo">
            <img src="<?php echo BASE_URL; ?>assets/img/logo-background.png" alt="logo">
            <span class="logo-text">Silent Place</span>
        </a>

        <!-- Menu para versão web -->
        <nav class="site-nav">
            <ul>
                <li><a href="<?php echo BASE_URL; ?>pages/catalogo.php">Catalogo</a></li>
                <li><a href="<?php echo BASE_URL; ?>pages/sobre_nos.php">Sobre</a></li>
                <li><a href="<?php echo BASE_URL; ?>pages/contato.php">Contato</a></li>
            </ul>
        </nav>
        <div class="line-divider"></div>

        <?php if ($loginStatus) { ?>
            <a id="login-status" class="login-a" href="<?php echo BASE_URL; ?>profile.php"><?php echo $nomeUsuario; ?>
                <img src="<?php echo $foto_usuario; ?>" alt="Foto de Perfil"></a>
        <?php } elseif ($userName) { ?>
            <a id="login-status" class="login-a" href="<?php echo BASE_URL; ?>profile.php"><?php echo htmlspecialchars($userName); ?>
                <img src="<?php echo htmlspecialchars($userPhoto); ?>" alt="Foto de Perfil"></a>
        <?php } else { ?>
            <a class="login-a" href="<?php echo BASE_URL; ?>pages/login.php">
                Login
                <img src="<?php echo $foto_usuario; ?>" alt="Ícone de Login" ?></a>
        <?php } ?>

        <!-- Menu lateral para versão mobile -->
        <nav id="sidebar" class="sidebar no-cursor-change hidden">
            <div class="sidebar-header">
                <div class="profile-pic">
                    <img src="https://via.placeholder.com/80" alt="Perfil">
                </div>
                <div class="profile-info">
                    <h3>Login</h3>
                </div>
            </div>
            <ul class="sidebar-menu">
                <li><a href="<?php echo BASE_URL; ?>pages/pages/sobre_nos.php">Sobre</a></li>
                <li><a href="<?php echo BASE_URL; ?>pages/pages/catalogo.php">Catalogo</a></li>
                <li><a href="<?php echo BASE_URL; ?>pages/pages/contato.php">Contato</a></li>
                <li><a href="<?php echo BASE_URL; ?>pages/pages/configuracoes.php">Configurações</a></li>
            </ul>
            <div id="closeBtnContainer" class="close-btn-container">
                <span id="closeBtn" class="close-btn">&#9664;</span>
            </div>
        </nav>
    </header>
    <script src="<?php echo BASE_URL; ?>assets/js/menu-script.js"></script>
</body>

</html>