<?php
function decryptData($data, $key)
{
    $data = base64_decode($data);
    $cipher = "aes-256-cbc";
    $ivlen = openssl_cipher_iv_length($cipher);
    $iv = substr($data, 0, $ivlen);
    $hmac = substr($data, $ivlen, $sha2len = 32);
    $ciphertext = substr($data, $ivlen + $sha2len);
    $original_data = openssl_decrypt($ciphertext, $cipher, $key, $options = OPENSSL_RAW_DATA, $iv);
    $calcmac = hash_hmac('sha256', $ciphertext, $key, $as_binary = true);
    if (hash_equals($hmac, $calcmac)) { // Verifica se a mensagem foi alterada durante a transmissão
        return $original_data;
    }
    return false;
}

$key = "chave_secreta";
